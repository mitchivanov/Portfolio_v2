import React from "react";
import "./contact.css";
import Header from "../components/header";
import Footer from "../components/footer";

function Contact() {
    return (
        <body>
            <Header />
        <div className="contact-section">
            <h1>Обо мне</h1>
            
        </div>
        <Footer />
        </body>
    );
}

export default Contact;
